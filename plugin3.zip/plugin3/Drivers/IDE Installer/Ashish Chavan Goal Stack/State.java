class State{
    int blocks;
    int on[][];
    int clear[];
    int ontable[];
    int arm;
    int hold[];

    public State(int blocks,String desc)
    {
        this.blocks=blocks;
        this.on=new int[blocks][blocks];
        this.clear=new int[blocks];
        this.ontable=new int[blocks];
        this.arm=-1;
        this.hold=new int[blocks];
    
        this.setState(desc);
    }
    public void setState(String desc)
    {
        String subs[]=desc.split("['^']+");
        for(int i=0;i<subs.length;i++)
        {
            String ele[]=subs[i].split("[() ]+");
            if(ele[1].contains("ontable"))
            {
                ontable[ele[2].charAt(0)%97]=1;
            }
            else if(ele[1].contains("on"))
            {
                on[ele[2].charAt(0)%97][ele[3].charAt(0)%97]=1;
            }
            else if(ele[1].contains("clear"))
            {
                clear[ele[2].charAt(0)%97]=1;
            }
            else if(ele[1].contains("hold"))
            {
                hold[ele[2].charAt(0)%97]=1;
            }
           

        }
    }
    
    public int check(String desc)
    {
        int flag=0;

        String subs[]=desc.split("['^']+");
        for(int i=0;i<subs.length;i++)
        {
            String ele[]=subs[i].split("[() ]+");
            if(ele[1].equals("ontable") && ontable[ele[2].charAt(0)%97]==1)
            {
                flag=1;
            }
            else if(ele[1].equals("on") && on[ele[2].charAt(0)%97][ele[3].charAt(0)%97]==1)
            {
                flag=1;
            }
            else if(ele[1].equals("clear") && clear[ele[2].charAt(0)%97]==1)
            {
                flag=1;
            }
            else if(ele[1].equals("hold") && hold[ele[2].charAt(0)%97]==1)
            {
                flag=1;
            }
            else if(ele[1].equals("AE") && arm==1)
            {
                flag=1;
            }
            else{
                return 0;
            }
        }

        return flag;
    }

    public int checktop(char c)
    {
        for(int i=0;i<blocks;i++)
        {
            if(on[i][c%97]==1)
            {
                return i;
            }
        }
        return -1;
    }

    public void performAction(String act)
    {
        String ele[]=act.split("[() ]+");

        int x,y;
        if(ele[1].contains("pickup"))
        {
            x=(int)(ele[2].charAt(0)%97);
            ontable[x]=0;
            arm=0;
            clear[x]=0;
            hold[x]=1;
        }
        else if(ele[1].contains("putdown"))
        {
            x=(int)(ele[2].charAt(0)%97);
            ontable[x]=1;
            arm=1;
            clear[x]=1;
            hold[x]=0;
        }
        else if(ele[1].contains("stack"))
        {
            x=(int)(ele[2].charAt(0)%97);
            y=(int)(ele[3].charAt(0)%97);

            on[x][y]=1;
            arm=1;
            clear[x]=1;
            hold[x]=0;
        }
        else if(ele[1].contains("unstack"))
        {
            x=(int)(ele[2].charAt(0)%97);
            y=(int)(ele[3].charAt(0)%97);

            on[x][y]=0;
            arm=0;
            clear[y]=1;
            hold[x]=1;
        }
        
    }
    public static void main(String args[])
    {
        State s = new State(3,"(ontable a)^(ontable b)");
        s.performAction("(putdown b)");
        System.out.println("Vithal Vithal");
    }
}