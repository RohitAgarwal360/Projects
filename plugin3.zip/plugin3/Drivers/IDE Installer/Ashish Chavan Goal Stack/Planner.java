import java.util.Scanner;
import java.util.Stack;
import java.util.ArrayList;
class Planner{

    State curr;
    int blocks;
    String goal_s;
    Stack s;
    ArrayList<String> steps;
    public Planner(String initial,String goal,int blocks)
    {
        this.goal_s=goal;
        this.curr=new State(blocks,initial);
        this.blocks=blocks;
        s=new Stack();
        steps=new ArrayList<String>();
    }


    public void solve()
    {
        int x,y,z;
        char a,b,c;
        String g;
        s.push(goal_s);
        
        
        String subs[]=goal_s.split("['^']+");

        for(int i=subs.length-1;i>=0;i--)
        {
            s.push(subs[i]);
        }
        
        while(!s.isEmpty())
        {
            g=(String)s.pop();
            if(g.contains("^"))
            {
                if(curr.check(g)==0)
                {
                    subs=g.split("['^']+");
                    for(int i=subs.length-1;i>=0;i--)
                    {
                        s.push(subs[i]);
                    }
                }
            }
            else if(g.contains("ontable") && curr.check(g)==0)
            {
                String ele[]=g.split("[() ]+");
                a=ele[2].charAt(0);
                s.push("(putdown "+a+")");
                s.push("(hold "+a+")");
            }
            else if(g.contains("on") && curr.check(g)==0)
            {
                String ele[]=g.split("[() ]+");
                a=ele[2].charAt(0);
                b=ele[3].charAt(0);
                s.push("(stack "+a+" "+b+")");
                s.push("(hold "+a+")");
            }
            else if(g.contains("clear") && curr.check(g)==0)
            {
                String ele[]=g.split("[() ]+");
                a=ele[2].charAt(0);
                x=a%97;
                if(curr.hold[x]==1)
                {
                    s.push("(putdown "+a+")");
                    s.push("(hold "+a+")");
                }
                else
                {
                    int t=curr.checktop(a);
                    
                    if(t!=-1)
                    {
                        a=(char)(t+97);
                        b=ele[2].charAt(0);
                        
                        s.push("(unstack "+a+" "+b+")");
                        s.push("(on "+a+" "+b+")^(clear "+a+")^(AE)");
                        s.push("(AE)");
                        s.push("(clear "+a+")");
                        s.push("(on "+a+" "+b+")");
                        

                    }
                }
            }
            else if(g.contains("hold") && curr.check(g)==0)
            {
                String ele[]=g.split("[() ]+");
                a=ele[2].charAt(0);
                x=a%97;
                if(curr.ontable[x]==1)
                {
                    s.push("(pickup "+a+")");
                    s.push("(ontable "+a+")^(clear "+a+")^(AE)");
                    s.push("(AE)");
                    s.push("(ontable "+a+")");
                    s.push("(clear "+a+")");
                }
                else
                {
                    int t=curr.checktop(a);
                    
                    if(t!=-1)
                    {
                        a=(char)(t+97);
                        b=ele[2].charAt(0);
                        
                        s.push("(unstack "+a+" "+b+")");
                        s.push("(on "+a+" "+b+")^(clear "+a+")^(AE)");
                        s.push("(AE)");
                        s.push("(clear "+a+")");
                        s.push("(on "+a+" "+b+")");
                        

                    }
                }
            }
            else if(g.contains("AE") && curr.check(g)==0)
            {
                for(int i=0;i<curr.blocks;i++)
                {
                    if(curr.hold[i]==1)
                    {
                        a=(char)(i+97);
                        s.push("(putdown "+a+")");
                        s.push("(hold "+a+")");
                    }
                }
            }
            else if(g.contains("pickup") || g.contains("stack") || g.contains("unstack") || g.contains("putdown"))
            {
                curr.performAction(g);
                steps.add(g);
            }
        }

        printOutput();
        
    }

    public void printOutput()
    {
        System.out.println(steps);
    }

    public static void main(String args[])
    {
        System.out.println(" Goal Stack Problem !!!");
        int blocks;
        String initial;
        String goal;

        blocks=4;
        initial="(ontable a)^(ontable c)^(ontable d)^(on b a)^(clear c)^(clear b)^(clear d)^(AE)";
        //goal="(ontable a)^(ontable c)^(on b a)^(on d c)^(clear b)^(clear d)^(AE)";
		goal="(ontable a)^(ontable d)^(on c a)^(on b d)^(clear b)^(clear c)^(AE)";
        Planner p=new Planner(initial,goal,blocks);
        p.solve();


    }
}
