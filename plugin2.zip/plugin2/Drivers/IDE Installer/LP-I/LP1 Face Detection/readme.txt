without explicit parallism

